# Input the two integers
num1 = int(input())
num2 = int(input())

# Print the sum of the two numbers
print(num1 + num2)

# Print the difference of the two numbers (first - second)
print(num1 - num2)

# Print the product of the two numbers
print(num1 * num2)
