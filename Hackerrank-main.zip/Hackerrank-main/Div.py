# Take input of the two integers
a = int(input())
b = int(input())

# Print the result of integer division (a // b)
print(a // b)

# Print the result of float division (a / b)
print(a / b)
